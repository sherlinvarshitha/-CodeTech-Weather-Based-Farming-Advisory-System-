# 🌾 KisanMitra — Weather-Based Farming Assistance System

A complete full-stack web application that gives farmers **real-time weather data, crop recommendations, SMS alerts, and rainfall tracking** — with offline fallback support.

---

## 📁 Project Structure

```
kisamitra/
├── backend/
│   ├── server.js              ← Express server + cron jobs
│   ├── package.json
│   ├── .env.example           ← Copy to .env and fill in keys
│   ├── db/
│   │   └── database.js        ← SQLite schema + seed data
│   ├── routes/
│   │   └── index.js           ← All REST API endpoints
│   └── services/
│       ├── weatherService.js  ← OpenWeatherMap API integration
│       ├── cropEngine.js      ← Rule-based crop recommendations
│       └── alertService.js    ← SMS via Twilio + alert management
└── frontend/
    └── public/
        ├── index.html         ← Complete single-page frontend
        └── js/
            └── api.js         ← API client with offline cache
```

---

## ⚙️ How to Run Locally (Step-by-Step)

### Prerequisites
- Node.js v18+ → Download from https://nodejs.org
- A free OpenWeatherMap API key → https://openweathermap.org/api

---

### Step 1 — Clone / Download the project

```bash
# If you have git:
git clone <your-repo-url>
cd kisamitra

# Or just unzip the project folder and open it
```

---

### Step 2 — Install backend dependencies

```bash
cd backend
npm install
```

This installs: Express, better-sqlite3, axios, node-cron, twilio, bcryptjs, jsonwebtoken, and more.

---

### Step 3 — Set up environment variables

```bash
# Copy the example file
cp .env.example .env
```

Now open `.env` in any text editor and fill in:

```env
PORT=5000
NODE_ENV=development

# Get free API key from https://openweathermap.org/api
# Sign up → My API Keys → copy the key
OPENWEATHER_API_KEY=abc123yourkeyhere

# Generate a random secret:  node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
JWT_SECRET=your_random_secret_here

# Optional — leave as-is if you don't have Twilio yet
# The system works without it (logs SMS to console instead)
TWILIO_ACCOUNT_SID=your_twilio_account_sid
TWILIO_AUTH_TOKEN=your_twilio_auth_token
TWILIO_PHONE_NUMBER=+1xxxxxxxxxx
```

> **Note:** The app works without a Twilio account. SMS will be logged to the console in demo mode.
> The app works without an OpenWeatherMap key too — it uses realistic mock data.

---

### Step 4 — Start the backend server

```bash
# From the backend/ directory:
node server.js

# Or with auto-reload during development:
npx nodemon server.js
```

You should see:
```
🌾 ══════════════════════════════════════════
   KisanMitra Backend Server Started
══════════════════════════════════════════
🌐 Server:   http://localhost:5000
🌤 API:      http://localhost:5000/api
📊 Frontend: http://localhost:5000
──────────────────────────────────────────
🔑 API Key:  ✅ Set
📱 SMS:      ❌ Not set (console log mode)
══════════════════════════════════════════
```

---

### Step 5 — Open the frontend

Open your browser and go to:
```
http://localhost:5000
```

That's it! The backend serves the frontend automatically.

---

## 🌐 API Endpoints Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/locations` | All locations/cities |
| GET | `/api/weather/current/:id` | Live weather (calls OpenWeatherMap) |
| GET | `/api/weather/forecast/:id` | 5-day forecast |
| GET | `/api/weather/history/:id?days=30` | Historical data |
| GET | `/api/weather/rainfall/:id?period=daily` | Rainfall aggregates |
| POST | `/api/weather` | Officer manual weather entry |
| GET | `/api/crops/recommend` | Crop recommendations |
| POST | `/api/farmers/register` | Farmer registration |
| POST | `/api/farmers/verify-otp` | OTP verification |
| GET | `/api/farmers` | List farmers |
| GET | `/api/alerts` | Active alerts |
| POST | `/api/alerts` | Create + broadcast alert |
| GET | `/api/alerts/sms-log` | SMS delivery log |
| GET | `/api/reports/daily/:id` | Daily weather report (text) |
| GET | `/api/reports/weekly/:id` | Weekly summary report |
| GET | `/api/admin/stats` | System statistics |
| GET | `/health` | Server health check |

---

## 🗄️ Database Schema

SQLite database stored at `backend/data/kisamitra.db`

| Table | Purpose |
|-------|---------|
| `locations` | Villages/cities with lat/lon |
| `farmers` | Registration, OTP, preferences |
| `weather_data` | Historical weather readings |
| `forecasts` | 5-day forecast cache |
| `alerts` | Alert history |
| `sms_log` | SMS delivery tracking |

---

## ⏰ Cron Jobs (Auto-Scheduled)

| Schedule | Task |
|----------|------|
| Every 30 min | Refresh weather for all locations |
| 7:00 AM daily | Send daily forecast SMS to all farmers |
| Monday 6:00 AM | Send weekly summary alert |

---

## 📱 SMS Integration

**Without Twilio (demo mode):**
SMS messages are printed to the console. All other features work normally.

**With Twilio (production):**
1. Sign up at https://www.twilio.com (free trial gives $15 credit)
2. Get your Account SID, Auth Token, and a phone number
3. Add to `.env` file
4. Restart the server

**For India (cheaper alternative):**
- MSG91: https://msg91.com — much cheaper for Indian phone numbers
- Exotel: https://exotel.com — also supports voice IVR calls

---

## 🌐 Free Hosting Options

### Option A — Railway (Recommended)
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login and deploy
railway login
railway init
railway up
```

### Option B — Render
1. Push code to GitHub
2. Go to https://render.com → New Web Service
3. Connect your repo
4. Set environment variables in the Render dashboard
5. Deploy!

### Option C — Local network (for rural offline use)
```bash
# Run on a Raspberry Pi or any computer on the local WiFi
# Farmers on the same network can access at:
http://192.168.1.X:5000
```

---

## 📴 Offline Strategy

The system handles offline scenarios in 3 ways:

1. **Browser cache** — `api.js` caches all API responses in `localStorage` for up to 7 days. Farmers can view weather, crops, and alerts without internet.

2. **Local SQLite** — all weather data is stored locally. If the cloud API fails, the app serves the last known reading.

3. **SMS fallback** — even if the app is offline, SMS alerts already sent are stored on farmers' phones. IVR voice calls work on 2G. Radio broadcast is the last resort.

---

## 🔮 Future Improvements

- IoT sensors (ESP8266/Arduino) → push real readings to `/api/weather`
- MongoDB Atlas sync for multi-device cloud backup
- ML model replacing the rule-based crop engine
- WhatsApp Business API for richer alerts
- Offline PWA with Service Worker
- Village-level weather station hardware kits
- Integration with IMD (India Meteorological Department) open data

---

## 🆓 Total Cost to Run for 250 Farmers

| Component | Cost |
|-----------|------|
| Backend hosting (Railway/Render) | ₹0 (free tier) |
| Database (SQLite local) | ₹0 |
| Weather data (OpenWeatherMap) | ₹0 (1000 calls/day free) |
| Push notifications (Firebase FCM) | ₹0 |
| SMS (Twilio/MSG91) | ~₹300–500/month |
| **Total** | **~₹400/month** |
