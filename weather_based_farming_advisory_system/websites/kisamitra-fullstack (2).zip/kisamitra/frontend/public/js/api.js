// js/api.js  —  API client with offline fallback
const BASE = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
  ? 'http://localhost:5000/api'
  : '/api';

// Offline cache using localStorage
const CACHE_TTL = 30 * 60 * 1000; // 30 minutes

function cacheSet(key, data) {
  try { localStorage.setItem('km_' + key, JSON.stringify({ data, ts: Date.now() })); } catch(e) {}
}
function cacheGet(key, maxAge = CACHE_TTL) {
  try {
    const raw = localStorage.getItem('km_' + key);
    if (!raw) return null;
    const { data, ts } = JSON.parse(raw);
    return Date.now() - ts < maxAge ? data : null;
  } catch(e) { return null; }
}

async function apiFetch(endpoint, options = {}, cacheKey = null, cacheMaxAge = CACHE_TTL) {
  try {
    const res = await fetch(BASE + endpoint, {
      headers: { 'Content-Type': 'application/json', ...options.headers },
      ...options,
    });
    const json = await res.json();
    if (cacheKey && json.success) cacheSet(cacheKey, json);
    return json;
  } catch (err) {
    console.warn('Network error, using cache:', err.message);
    if (cacheKey) {
      const cached = cacheGet(cacheKey, 7 * 24 * 60 * 60 * 1000); // 7-day fallback
      if (cached) return { ...cached, fromCache: true };
    }
    return { success: false, error: 'Network unavailable', offline: true };
  }
}

const API = {
  getLocations:      ()             => apiFetch('/locations', {}, 'locations', 24*60*60*1000),
  getCurrentWeather: (locId)        => apiFetch(`/weather/current/${locId}`, {}, `weather_${locId}`),
  getForecast:       (locId)        => apiFetch(`/weather/forecast/${locId}`, {}, `forecast_${locId}`),
  getHistory:        (locId, days)  => apiFetch(`/weather/history/${locId}?days=${days}`, {}, `history_${locId}_${days}`, 60*60*1000),
  getRainfall:       (locId, period)=> apiFetch(`/weather/rainfall/${locId}?period=${period}`, {}, `rain_${locId}_${period}`, 60*60*1000),
  getRecommendations:(p)            => apiFetch(`/crops/recommend?${new URLSearchParams(p)}`, {}, `crops_${JSON.stringify(p)}`, 60*60*1000),
  getAlerts:         (locId)        => apiFetch(`/alerts?locationId=${locId}`, {}, `alerts_${locId}`, 5*60*1000),
  getDailyReport:    (locId)        => apiFetch(`/reports/daily/${locId}`),
  getWeeklyReport:   (locId)        => apiFetch(`/reports/weekly/${locId}`),
  getAdminStats:     ()             => apiFetch('/admin/stats', {}, 'admin_stats', 5*60*1000),

  register: (data) => apiFetch('/farmers/register', { method: 'POST', body: JSON.stringify(data) }),
  verifyOTP: (data) => apiFetch('/farmers/verify-otp', { method: 'POST', body: JSON.stringify(data) }),
  resendOTP: (phone) => apiFetch('/farmers/resend-otp', { method: 'POST', body: JSON.stringify({ phone }) }),
  getFarmers: (locId, page) => apiFetch(`/farmers?location_id=${locId || ''}&page=${page || 1}`, {}, `farmers_${locId}_${page}`, 2*60*1000),

  postAlert: (data) => apiFetch('/alerts', { method: 'POST', body: JSON.stringify(data) }),
  postWeather: (data) => apiFetch('/weather', { method: 'POST', body: JSON.stringify(data) }),
  getSMSLog: () => apiFetch('/alerts/sms-log', {}, 'sms_log', 2*60*1000),
};

window.API = API;
window.cacheGet = cacheGet;
window.cacheSet = cacheSet;
