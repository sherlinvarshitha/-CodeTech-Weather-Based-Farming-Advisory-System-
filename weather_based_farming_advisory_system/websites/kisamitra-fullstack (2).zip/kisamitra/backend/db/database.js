// db/database.js  —  SQLite schema + initialization
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = path.join(__dirname, '..', 'data', 'kisamitra.db');

// Ensure data directory exists
const dataDir = path.dirname(DB_PATH);
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(DB_PATH);

// Enable WAL mode for better concurrent read performance
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ─────────────────────────────────────────────
//  CREATE TABLES
// ─────────────────────────────────────────────
db.exec(`
  -- Locations / Villages
  CREATE TABLE IF NOT EXISTS locations (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    district    TEXT NOT NULL,
    state       TEXT NOT NULL DEFAULT 'Maharashtra',
    latitude    REAL NOT NULL,
    longitude   REAL NOT NULL,
    created_at  TEXT DEFAULT (datetime('now'))
  );

  -- Farmers
  CREATE TABLE IF NOT EXISTS farmers (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    phone         TEXT NOT NULL UNIQUE,
    phone_verified INTEGER DEFAULT 0,
    location_id   INTEGER REFERENCES locations(id),
    village       TEXT,
    soil_type     TEXT DEFAULT 'black',
    farm_size     REAL,
    crops         TEXT,            -- JSON array stored as text
    alert_sms     INTEGER DEFAULT 1,
    alert_push    INTEGER DEFAULT 1,
    alert_ivr     INTEGER DEFAULT 0,
    otp           TEXT,
    otp_expires   TEXT,
    created_at    TEXT DEFAULT (datetime('now'))
  );

  -- Weather readings (historical + current)
  CREATE TABLE IF NOT EXISTS weather_data (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    location_id   INTEGER REFERENCES locations(id),
    location_name TEXT,
    temperature   REAL,
    feels_like    REAL,
    temp_min      REAL,
    temp_max      REAL,
    humidity      INTEGER,
    pressure      INTEGER,
    wind_speed    REAL,
    wind_deg      INTEGER,
    rainfall_1h   REAL DEFAULT 0,
    rainfall_24h  REAL DEFAULT 0,
    cloud_cover   INTEGER,
    visibility    INTEGER,
    weather_main  TEXT,
    weather_desc  TEXT,
    weather_icon  TEXT,
    uv_index      REAL,
    recorded_at   TEXT DEFAULT (datetime('now')),
    source        TEXT DEFAULT 'openweathermap'
  );

  -- 5-day forecast cache
  CREATE TABLE IF NOT EXISTS forecasts (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    location_id   INTEGER REFERENCES locations(id),
    forecast_time TEXT NOT NULL,
    temperature   REAL,
    temp_min      REAL,
    temp_max      REAL,
    humidity      INTEGER,
    rainfall      REAL DEFAULT 0,
    wind_speed    REAL,
    weather_main  TEXT,
    weather_desc  TEXT,
    weather_icon  TEXT,
    fetched_at    TEXT DEFAULT (datetime('now'))
  );

  -- Alerts log
  CREATE TABLE IF NOT EXISTS alerts (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    location_id   INTEGER,
    type          TEXT NOT NULL,     -- storm, drought, heat, rain, custom
    severity      TEXT DEFAULT 'info', -- info, warning, danger
    title         TEXT NOT NULL,
    message       TEXT NOT NULL,
    sent_sms      INTEGER DEFAULT 0,
    sent_push     INTEGER DEFAULT 0,
    recipients    INTEGER DEFAULT 0,
    created_by    TEXT DEFAULT 'system',
    created_at    TEXT DEFAULT (datetime('now'))
  );

  -- SMS log
  CREATE TABLE IF NOT EXISTS sms_log (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    farmer_id     INTEGER REFERENCES farmers(id),
    phone         TEXT NOT NULL,
    message       TEXT NOT NULL,
    alert_id      INTEGER,
    status        TEXT DEFAULT 'pending',  -- pending, sent, failed
    sent_at       TEXT DEFAULT (datetime('now'))
  );

  -- Indexes for fast lookups
  CREATE INDEX IF NOT EXISTS idx_weather_location ON weather_data(location_id, recorded_at);
  CREATE INDEX IF NOT EXISTS idx_forecast_location ON forecasts(location_id, forecast_time);
  CREATE INDEX IF NOT EXISTS idx_farmers_phone ON farmers(phone);
  CREATE INDEX IF NOT EXISTS idx_alerts_location ON alerts(location_id, created_at);
`);

// ─────────────────────────────────────────────
//  SEED DEFAULT LOCATIONS (Maharashtra cities)
// ─────────────────────────────────────────────
const seedLocations = db.prepare(`
  INSERT OR IGNORE INTO locations (name, district, latitude, longitude)
  VALUES (?, ?, ?, ?)
`);

const defaultLocations = [
  ['Nashik',      'Nashik',      20.0059, 73.7897],
  ['Pune',        'Pune',        18.5204, 73.8567],
  ['Nagpur',      'Nagpur',      21.1458, 79.0882],
  ['Aurangabad',  'Aurangabad',  19.8762, 75.3433],
  ['Kolhapur',    'Kolhapur',    16.7050, 74.2433],
  ['Solapur',     'Solapur',     17.6805, 75.9064],
  ['Amravati',    'Amravati',    20.9320, 77.7523],
  ['Jalgaon',     'Jalgaon',     21.0077, 75.5626],
];

const insertMany = db.transaction(() => {
  for (const loc of defaultLocations) seedLocations.run(...loc);
});
insertMany();

console.log('✅ Database initialized:', DB_PATH);

module.exports = db;
