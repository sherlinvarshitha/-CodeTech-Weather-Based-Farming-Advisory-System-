// server.js  —  KisanMitra Backend Entry Point
require('dotenv').config();

const express    = require('express');
const cors       = require('cors');
const path       = require('path');
const cron       = require('node-cron');
const rateLimit  = require('express-rate-limit');

const routes         = require('./routes/index');
const weatherService = require('./services/weatherService');
const alertService   = require('./services/alertService');
const db             = require('./db/database');

const app  = express();
const PORT = process.env.PORT || 5000;

// ─────────────────────────────────────────────
//  MIDDLEWARE
// ─────────────────────────────────────────────
app.use(cors({
  origin: [
    process.env.FRONTEND_URL || 'http://localhost:3000',
    'http://localhost:5000',
    'http://127.0.0.1:5500',  // VS Code Live Server
    /^http:\/\/192\.168\./,   // Local network access (farmers on same WiFi)
  ],
  credentials: true,
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve frontend from /frontend/public
app.use(express.static(path.join(__dirname, '..', 'frontend', 'public')));

// Rate limiting (prevent abuse)
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 200,
  message: { success: false, error: 'Too many requests. Please try again later.' },
});
app.use('/api/', apiLimiter);

// ─────────────────────────────────────────────
//  API ROUTES
// ─────────────────────────────────────────────
app.use('/api', routes);

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    apiKey: !!process.env.OPENWEATHER_API_KEY && process.env.OPENWEATHER_API_KEY !== 'your_openweathermap_api_key_here',
    sms: !!process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_ACCOUNT_SID !== 'your_twilio_account_sid',
  });
});

// Fallback: serve index.html for any unmatched routes (SPA support)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'frontend', 'public', 'index.html'));
});

// ─────────────────────────────────────────────
//  CRON JOBS — Scheduled Tasks
// ─────────────────────────────────────────────

// Every 30 minutes: refresh weather for all locations
cron.schedule('*/30 * * * *', async () => {
  console.log('⏰ [CRON] Refreshing weather for all locations...');
  const locations = db.prepare('SELECT * FROM locations').all();
  for (const loc of locations) {
    try {
      const w = await weatherService.fetchCurrentWeather(loc.id);
      const extremes = weatherService.detectExtremeWeather(w);
      for (const alert of extremes) {
        await alertService.createAlert({ ...alert, location_id: loc.id });
      }
    } catch (err) {
      console.error(`Weather refresh failed for ${loc.name}:`, err.message);
    }
  }
  console.log(`✅ Weather refreshed for ${locations.length} locations`);
});

// Daily 7:00 AM: Send daily forecast SMS to all verified farmers
cron.schedule('0 7 * * *', async () => {
  console.log('⏰ [CRON] Sending daily 7AM forecast SMS...');
  const locations = db.prepare('SELECT * FROM locations').all();

  for (const loc of locations) {
    const latest = db.prepare(
      'SELECT * FROM weather_data WHERE location_id = ? ORDER BY recorded_at DESC LIMIT 1'
    ).get(loc.id);

    if (!latest) continue;

    const msg = `Good morning! ${loc.name} today: ${latest.temperature}°C, ${latest.weather_desc || latest.weather_main}. Humidity ${latest.humidity}%. Rain ${latest.rainfall_1h}mm. -KisanMitra`;

    await alertService.createAlert({
      location_id: loc.id,
      type: 'daily_forecast',
      severity: 'info',
      title: `Daily Forecast - ${loc.name}`,
      message: msg,
      created_by: 'cron',
    });
  }
  console.log('✅ Daily forecast SMS broadcast complete');
});

// Weekly Monday 6:00 AM: Weekly summary
cron.schedule('0 6 * * 1', async () => {
  console.log('⏰ [CRON] Sending weekly summary...');
  await alertService.createAlert({
    type: 'weekly_summary',
    severity: 'info',
    title: 'Weekly Weather Summary',
    message: 'Your weekly weather report is ready. Check the KisanMitra app for detailed rainfall, temperature trends, and crop advice for the coming week.',
    created_by: 'cron',
  });
});

// ─────────────────────────────────────────────
//  START SERVER
// ─────────────────────────────────────────────
app.listen(PORT, () => {
  console.log('\n🌾 ══════════════════════════════════════════');
  console.log('   KisanMitra Backend Server Started');
  console.log('══════════════════════════════════════════');
  console.log(`🌐 Server:   http://localhost:${PORT}`);
  console.log(`🌤 API:      http://localhost:${PORT}/api`);
  console.log(`🏥 Health:   http://localhost:${PORT}/health`);
  console.log(`📊 Frontend: http://localhost:${PORT}`);
  console.log('──────────────────────────────────────────');
  console.log(`🔑 API Key:  ${process.env.OPENWEATHER_API_KEY && process.env.OPENWEATHER_API_KEY !== 'your_openweathermap_api_key_here' ? '✅ Set' : '❌ Not set (demo mode)'}`);
  console.log(`📱 SMS:      ${process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_ACCOUNT_SID !== 'your_twilio_account_sid' ? '✅ Twilio configured' : '❌ Not set (console log mode)'}`);
  console.log('══════════════════════════════════════════\n');
});

module.exports = app;
