// routes/index.js  —  All REST API endpoints
const express  = require('express');
const router   = express.Router();
const db       = require('../db/database');
const weather  = require('../services/weatherService');
const crops    = require('../services/cropEngine');
const alerts   = require('../services/alertService');
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');

// ════════════════════════════════════════════
//  LOCATIONS
// ════════════════════════════════════════════

// GET /api/locations
router.get('/locations', (req, res) => {
  const locs = db.prepare('SELECT * FROM locations ORDER BY name').all();
  res.json({ success: true, data: locs });
});

// ════════════════════════════════════════════
//  WEATHER
// ════════════════════════════════════════════

// GET /api/weather/current/:locationId
router.get('/weather/current/:locationId', async (req, res) => {
  try {
    const data = await weather.fetchCurrentWeather(+req.params.locationId);
    const extremeAlerts = weather.detectExtremeWeather(data);

    // Auto-create extreme weather alerts
    for (const alert of extremeAlerts) {
      await alerts.createAlert({ ...alert, location_id: +req.params.locationId });
    }

    res.json({ success: true, data, autoAlerts: extremeAlerts });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/weather/forecast/:locationId
router.get('/weather/forecast/:locationId', async (req, res) => {
  try {
    const data = await weather.fetchForecast(+req.params.locationId);
    res.json({ success: true, data });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/weather/history/:locationId?days=30
router.get('/weather/history/:locationId', (req, res) => {
  const days = Math.min(+req.query.days || 30, 365);
  const rows = weather.getWeatherHistory(+req.params.locationId, days);
  res.json({ success: true, data: rows, count: rows.length });
});

// GET /api/weather/rainfall/:locationId  — aggregated daily/weekly/monthly
router.get('/weather/rainfall/:locationId', (req, res) => {
  const { period = 'daily' } = req.query;
  const locId = +req.params.locationId;

  let query;
  if (period === 'monthly') {
    query = `
      SELECT strftime('%Y-%m', recorded_at) as period,
             ROUND(SUM(rainfall_1h), 1)     as total_mm,
             COUNT(*)                        as readings
      FROM weather_data WHERE location_id = ?
      GROUP BY period ORDER BY period DESC LIMIT 12
    `;
  } else if (period === 'weekly') {
    query = `
      SELECT strftime('%Y-W%W', recorded_at) as period,
             ROUND(SUM(rainfall_1h), 1)      as total_mm,
             COUNT(*)                         as readings
      FROM weather_data WHERE location_id = ?
      GROUP BY period ORDER BY period DESC LIMIT 12
    `;
  } else {
    query = `
      SELECT strftime('%Y-%m-%d', recorded_at) as period,
             ROUND(SUM(rainfall_1h), 1)         as total_mm,
             ROUND(MAX(rainfall_1h), 1)          as max_mm,
             COUNT(*)                            as readings
      FROM weather_data WHERE location_id = ?
        AND recorded_at >= datetime('now', '-30 days')
      GROUP BY period ORDER BY period DESC LIMIT 30
    `;
  }

  const data = db.prepare(query).all(locId);
  res.json({ success: true, data, period });
});

// POST /api/weather  — officer manual weather entry
router.post('/weather', (req, res) => {
  const {
    location_id, temperature, feels_like, humidity, pressure,
    wind_speed, rainfall_1h, cloud_cover, weather_main, weather_desc,
  } = req.body;

  if (!location_id || temperature == null) {
    return res.status(400).json({ success: false, error: 'location_id and temperature required' });
  }

  const loc = db.prepare('SELECT * FROM locations WHERE id = ?').get(location_id);
  db.prepare(`
    INSERT INTO weather_data
      (location_id, location_name, temperature, feels_like, humidity, pressure,
       wind_speed, rainfall_1h, cloud_cover, weather_main, weather_desc, source)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'manual')
  `).run(
    location_id, loc?.name || '', temperature, feels_like || temperature + 2,
    humidity || 65, pressure || 1010, wind_speed || 0,
    rainfall_1h || 0, cloud_cover || 0, weather_main || 'Clear', weather_desc || 'clear sky'
  );

  res.json({ success: true, message: 'Weather data saved successfully' });
});

// ════════════════════════════════════════════
//  CROP RECOMMENDATIONS
// ════════════════════════════════════════════

// GET /api/crops/recommend?locationId=1&season=kharif&soil=black&water=rain
router.get('/crops/recommend', async (req, res) => {
  try {
    const { locationId, season = 'kharif', soil = 'black', water = 'rain' } = req.query;

    let temperature = 28, humidity = 65, rainfall_monthly = 250;

    if (locationId) {
      const latest = db.prepare(
        'SELECT * FROM weather_data WHERE location_id = ? ORDER BY recorded_at DESC LIMIT 1'
      ).get(+locationId);
      if (latest) {
        temperature      = latest.temperature;
        humidity         = latest.humidity;
      }

      // Sum last 30 days rainfall
      const rain = db.prepare(`
        SELECT COALESCE(SUM(rainfall_1h), 0) as total
        FROM weather_data
        WHERE location_id = ? AND recorded_at >= datetime('now', '-30 days')
      `).get(+locationId);
      rainfall_monthly = rain?.total || 250;
    }

    const result = crops.getRecommendations({
      temperature, humidity, rainfall_monthly,
      soil_type: soil, season, water_availability: water,
    });

    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ════════════════════════════════════════════
//  FARMER REGISTRATION
// ════════════════════════════════════════════

// POST /api/farmers/register
router.post('/farmers/register', async (req, res) => {
  const { name, phone, location_id, village, soil_type, farm_size, crops: farmerCrops, alert_sms, alert_push } = req.body;

  if (!name || !phone) {
    return res.status(400).json({ success: false, error: 'Name and phone are required' });
  }

  // Check duplicate
  const existing = db.prepare('SELECT id FROM farmers WHERE phone = ?').get(phone);
  if (existing) {
    return res.status(409).json({ success: false, error: 'Phone number already registered' });
  }

  // Generate OTP (6-digit)
  const otp = String(Math.floor(100000 + Math.random() * 900000));
  const otp_expires = new Date(Date.now() + 10 * 60 * 1000).toISOString(); // 10 min

  db.prepare(`
    INSERT INTO farmers (name, phone, location_id, village, soil_type, farm_size,
                         crops, alert_sms, alert_push, otp, otp_expires)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    name, phone, location_id || 1, village || '',
    soil_type || 'black', farm_size || 0,
    JSON.stringify(farmerCrops || []),
    alert_sms ? 1 : 0, alert_push ? 1 : 0,
    otp, otp_expires
  );

  // Send OTP via SMS
  const smsMsg = `KisanMitra: Your OTP is ${otp}. Valid for 10 minutes. Do not share with anyone.`;
  await alerts.sendSMS(phone, smsMsg);

  console.log(`🔑 OTP for ${phone}: ${otp}`); // always log for demo

  res.json({
    success: true,
    message: `OTP sent to ${phone}`,
    otp_hint: process.env.NODE_ENV === 'development' ? otp : undefined, // only in dev!
  });
});

// POST /api/farmers/verify-otp
router.post('/farmers/verify-otp', (req, res) => {
  const { phone, otp } = req.body;
  if (!phone || !otp) return res.status(400).json({ success: false, error: 'phone and otp required' });

  const farmer = db.prepare('SELECT * FROM farmers WHERE phone = ?').get(phone);
  if (!farmer) return res.status(404).json({ success: false, error: 'Farmer not found' });
  if (farmer.phone_verified) return res.json({ success: true, message: 'Already verified' });

  const now = new Date();
  const expires = new Date(farmer.otp_expires);
  if (farmer.otp !== otp) return res.status(400).json({ success: false, error: 'Invalid OTP' });
  if (now > expires) return res.status(400).json({ success: false, error: 'OTP expired. Request a new one.' });

  db.prepare("UPDATE farmers SET phone_verified = 1, otp = NULL, otp_expires = NULL WHERE phone = ?").run(phone);

  const token = jwt.sign({ farmerId: farmer.id, phone }, process.env.JWT_SECRET || 'dev_secret', { expiresIn: '30d' });

  res.json({ success: true, message: 'Phone verified! Registration complete.', token, farmerId: farmer.id });
});

// POST /api/farmers/resend-otp
router.post('/farmers/resend-otp', async (req, res) => {
  const { phone } = req.body;
  const farmer = db.prepare('SELECT * FROM farmers WHERE phone = ?').get(phone);
  if (!farmer) return res.status(404).json({ success: false, error: 'Farmer not found' });

  const otp = String(Math.floor(100000 + Math.random() * 900000));
  const otp_expires = new Date(Date.now() + 10 * 60 * 1000).toISOString();
  db.prepare('UPDATE farmers SET otp = ?, otp_expires = ? WHERE phone = ?').run(otp, otp_expires, phone);

  const smsMsg = `KisanMitra: Your new OTP is ${otp}. Valid for 10 minutes.`;
  await alerts.sendSMS(phone, smsMsg);
  console.log(`🔑 Resent OTP for ${phone}: ${otp}`);

  res.json({ success: true, message: 'OTP resent', otp_hint: process.env.NODE_ENV === 'development' ? otp : undefined });
});

// GET /api/farmers
router.get('/farmers', (req, res) => {
  const { location_id, page = 1, limit = 20 } = req.query;
  const offset = (page - 1) * limit;

  const query = location_id
    ? 'SELECT f.*, l.name as location_name FROM farmers f LEFT JOIN locations l ON l.id = f.location_id WHERE f.location_id = ? LIMIT ? OFFSET ?'
    : 'SELECT f.*, l.name as location_name FROM farmers f LEFT JOIN locations l ON l.id = f.location_id LIMIT ? OFFSET ?';

  const farmers = location_id
    ? db.prepare(query).all(location_id, +limit, offset)
    : db.prepare(query).all(+limit, offset);

  const total = db.prepare('SELECT COUNT(*) as c FROM farmers').get().c;

  // Mask phone numbers for privacy
  const masked = farmers.map(f => ({ ...f, phone: f.phone.slice(0, 5) + '****' + f.phone.slice(-2) }));
  res.json({ success: true, data: masked, total, page: +page });
});

// ════════════════════════════════════════════
//  ALERTS
// ════════════════════════════════════════════

// GET /api/alerts?locationId=1
router.get('/alerts', (req, res) => {
  const { locationId, limit = 20 } = req.query;
  const data = alerts.getAlerts(locationId ? +locationId : null, +limit);
  res.json({ success: true, data });
});

// POST /api/alerts  — officer sends manual alert
router.post('/alerts', async (req, res) => {
  try {
    const { location_id, type, severity, title, message } = req.body;
    if (!title || !message) return res.status(400).json({ success: false, error: 'title and message required' });

    const result = await alerts.createAlert({ location_id, type: type || 'custom', severity: severity || 'info', title, message, created_by: 'officer' });
    res.json({ success: true, ...result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/alerts/sms-log
router.get('/alerts/sms-log', (req, res) => {
  const log = alerts.getSMSLog(+req.query.limit || 50);
  res.json({ success: true, data: log });
});

// ════════════════════════════════════════════
//  REPORTS
// ════════════════════════════════════════════

// GET /api/reports/daily/:locationId
router.get('/reports/daily/:locationId', (req, res) => {
  const locId = +req.params.locationId;
  const loc = db.prepare('SELECT * FROM locations WHERE id = ?').get(locId);
  const latest = db.prepare('SELECT * FROM weather_data WHERE location_id = ? ORDER BY recorded_at DESC LIMIT 1').get(locId);
  const todayRain = db.prepare(`
    SELECT ROUND(SUM(rainfall_1h), 1) as total
    FROM weather_data WHERE location_id = ? AND recorded_at >= date('now')
  `).get(locId);
  const activeAlerts = db.prepare('SELECT * FROM alerts WHERE (location_id = ? OR location_id IS NULL) AND created_at >= date("now") ORDER BY severity DESC LIMIT 3').all(locId);

  if (!latest) return res.status(404).json({ success: false, error: 'No weather data for this location' });

  const today = new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' });
  const report = `
╔════════════════════════════════════════════╗
║        KISAMITRA DAILY WEATHER REPORT      ║
╚════════════════════════════════════════════╝

Date       : ${today}
Location   : ${loc?.name || 'Unknown'}, ${loc?.district || ''}, ${loc?.state || ''}
Station    : KisanMitra Agri Weather Network
Data Type  : ${latest.source === 'openweathermap' ? 'Live (OpenWeatherMap API)' : latest.source === 'manual' ? 'Officer Entry' : 'Cached/Demo'}

─────────── CURRENT CONDITIONS ─────────────
Temperature  : ${latest.temperature}°C (Feels like ${latest.feels_like}°C)
  Min / Max  : ${latest.temp_min}°C / ${latest.temp_max}°C
Humidity     : ${latest.humidity}%
Pressure     : ${latest.pressure} hPa
Condition    : ${latest.weather_desc || latest.weather_main || 'N/A'}

─────────── WIND & RAIN ─────────────────────
Wind Speed   : ${latest.wind_speed} km/h
Cloud Cover  : ${latest.cloud_cover}%
Rainfall (1h): ${latest.rainfall_1h} mm
Rainfall (Today): ${todayRain?.total || 0} mm
Visibility   : ${latest.visibility} km

─────────── TODAY'S ALERTS ──────────────────
${activeAlerts.length
    ? activeAlerts.map(a => `[${a.severity.toUpperCase()}] ${a.title}\n  ${a.message}`).join('\n\n')
    : 'No active alerts for today.'}

─────────── CROP ADVISORY ───────────────────
${latest.humidity > 80
    ? '⚠️ High humidity — monitor crops for fungal diseases'
    : '✅ Humidity normal — good conditions for most crops'}
${latest.temperature > 35
    ? '⚠️ High temperature — irrigate in morning/evening only'
    : '✅ Temperature within optimal range for Kharif crops'}
${latest.rainfall_1h > 20
    ? '⚠️ Heavy rain — avoid pesticide spraying for 24 hrs'
    : '✅ Light/no rain — safe to spray if needed'}

─────────────────────────────────────────────
Generated   : ${new Date().toLocaleString('en-IN')}
Issued by   : KisanMitra System
Support     : kisanmitra.help | 1800-XXX-XXXX
─────────────────────────────────────────────
`.trim();

  res.json({ success: true, report, data: latest, location: loc });
});

// GET /api/reports/weekly/:locationId
router.get('/reports/weekly/:locationId', (req, res) => {
  const locId = +req.params.locationId;
  const loc = db.prepare('SELECT * FROM locations WHERE id = ?').get(locId);

  const stats = db.prepare(`
    SELECT
      ROUND(AVG(temperature), 1) as avg_temp,
      ROUND(MAX(temp_max), 1)    as max_temp,
      ROUND(MIN(temp_min), 1)    as min_temp,
      ROUND(AVG(humidity), 0)    as avg_humidity,
      ROUND(SUM(rainfall_1h), 1) as total_rain,
      ROUND(AVG(wind_speed), 1)  as avg_wind,
      COUNT(*)                   as readings
    FROM weather_data
    WHERE location_id = ? AND recorded_at >= datetime('now', '-7 days')
  `).get(locId);

  const daily = db.prepare(`
    SELECT strftime('%d %b', recorded_at) as day,
           ROUND(AVG(temperature), 1)     as temp,
           ROUND(SUM(rainfall_1h), 1)     as rain,
           ROUND(AVG(humidity), 0)        as humidity
    FROM weather_data WHERE location_id = ? AND recorded_at >= datetime('now', '-7 days')
    GROUP BY strftime('%Y-%m-%d', recorded_at)
    ORDER BY recorded_at
  `).all(locId);

  const report = `
╔════════════════════════════════════════════╗
║       KISAMITRA WEEKLY WEATHER SUMMARY     ║
╚════════════════════════════════════════════╝

Week     : ${new Date(Date.now() - 7 * 86400000).toLocaleDateString('en-IN')} – ${new Date().toLocaleDateString('en-IN')}
Location : ${loc?.name || 'Unknown'}, ${loc?.state || 'Maharashtra'}

─────────── WEEK SUMMARY ────────────────────
Avg Temperature : ${stats?.avg_temp || 'N/A'}°C
Max Temperature : ${stats?.max_temp || 'N/A'}°C
Min Temperature : ${stats?.min_temp || 'N/A'}°C
Avg Humidity    : ${stats?.avg_humidity || 'N/A'}%
Total Rainfall  : ${stats?.total_rain || 0} mm
Avg Wind Speed  : ${stats?.avg_wind || 'N/A'} km/h
Data Readings   : ${stats?.readings || 0}

─────────── DAY-BY-DAY BREAKDOWN ────────────
${daily.length
    ? daily.map(d => `${d.day.padEnd(10)} Temp: ${d.temp}°C  Rain: ${d.rain}mm  Humidity: ${d.humidity}%`).join('\n')
    : 'No daily data available for this week.'}

─────────── WEEK ASSESSMENT ─────────────────
${(stats?.total_rain || 0) > 100
    ? '🌧 Above-average rainfall this week — check drainage'
    : (stats?.total_rain || 0) > 20
    ? '💧 Moderate rainfall — continue normal irrigation schedule'
    : '🏜 Low rainfall — increase irrigation frequency'}

─────────────────────────────────────────────
Generated : ${new Date().toLocaleString('en-IN')}
KisanMitra | kisanmitra.help
─────────────────────────────────────────────
`.trim();

  res.json({ success: true, report, stats, daily, location: loc });
});

// ════════════════════════════════════════════
//  ADMIN / SYSTEM STATS
// ════════════════════════════════════════════
router.get('/admin/stats', (req, res) => {
  const farmers   = db.prepare('SELECT COUNT(*) as c FROM farmers WHERE phone_verified = 1').get().c;
  const locations = db.prepare('SELECT COUNT(*) as c FROM locations').get().c;
  const alertsSent = db.prepare('SELECT COUNT(*) as c FROM alerts WHERE created_at >= date("now", "-30 days")').get().c;
  const smsSent   = db.prepare('SELECT COUNT(*) as c FROM sms_log WHERE status = "sent"').get().c;
  const weatherReadings = db.prepare('SELECT COUNT(*) as c FROM weather_data').get().c;

  res.json({
    success: true,
    stats: { farmers, locations, alertsSent, smsSent, weatherReadings },
  });
});

module.exports = router;
