// services/alertService.js  —  SMS broadcast + alert management
const db = require('../db/database');

// ─────────────────────────────────────────────
//  Save alert to DB and optionally send SMS
// ─────────────────────────────────────────────
async function createAlert({ location_id, type, severity, title, message, created_by = 'system' }) {
  const result = db.prepare(`
    INSERT INTO alerts (location_id, type, severity, title, message, created_by)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(location_id, type, severity, title, message, created_by);

  const alertId = result.lastInsertRowid;

  // Get all farmers for this location (or all if no location)
  const query = location_id
    ? 'SELECT * FROM farmers WHERE location_id = ? AND alert_sms = 1 AND phone_verified = 1'
    : 'SELECT * FROM farmers WHERE alert_sms = 1 AND phone_verified = 1';

  const farmers = location_id
    ? db.prepare(query).all(location_id)
    : db.prepare(query).all();

  // Build SMS text (keep under 160 chars for single SMS)
  const smsText = buildSMSText({ severity, title, message });

  // Send SMS to each farmer
  let sentCount = 0;
  for (const farmer of farmers) {
    const status = await sendSMS(farmer.phone, smsText, alertId);
    if (status === 'sent') sentCount++;
  }

  // Update recipients count
  db.prepare('UPDATE alerts SET sent_sms = 1, recipients = ? WHERE id = ?')
    .run(sentCount, alertId);

  return { alertId, recipients: sentCount, smsText };
}

// ─────────────────────────────────────────────
//  Send a single SMS
// ─────────────────────────────────────────────
async function sendSMS(phone, message, alertId = null) {
  // Log to DB first
  const logResult = db.prepare(`
    INSERT INTO sms_log (phone, message, alert_id, status)
    VALUES (?, ?, ?, 'pending')
  `).run(phone, message, alertId);

  const logId = logResult.lastInsertRowid;

  // Try Twilio if configured
  const { TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER } = process.env;

  if (TWILIO_ACCOUNT_SID && TWILIO_ACCOUNT_SID !== 'your_twilio_account_sid') {
    try {
      const twilio = require('twilio')(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);
      await twilio.messages.create({
        body: message,
        from: TWILIO_PHONE_NUMBER,
        to: phone,
      });
      db.prepare("UPDATE sms_log SET status = 'sent' WHERE id = ?").run(logId);
      console.log(`✅ SMS sent to ${phone}`);
      return 'sent';
    } catch (err) {
      console.error(`❌ SMS failed to ${phone}:`, err.message);
      db.prepare("UPDATE sms_log SET status = 'failed' WHERE id = ?").run(logId);
      return 'failed';
    }
  } else {
    // Demo mode — log to console, mark as 'sent' for testing
    console.log(`📱 [DEMO SMS] → ${phone}: ${message}`);
    db.prepare("UPDATE sms_log SET status = 'sent' WHERE id = ?").run(logId);
    return 'sent';
  }
}

// ─────────────────────────────────────────────
//  Format SMS message (max 160 chars for 1 SMS)
// ─────────────────────────────────────────────
function buildSMSText({ severity, title, message }) {
  const prefix = severity === 'danger' ? 'URGENT-' : severity === 'warning' ? 'ALERT-' : 'INFO-';
  const fullMsg = `KisanMitra ${prefix}${title}: ${message} -KisanMitra`;
  return fullMsg.length > 160 ? fullMsg.slice(0, 157) + '...' : fullMsg;
}

// ─────────────────────────────────────────────
//  Get recent alerts
// ─────────────────────────────────────────────
function getAlerts(locationId, limit = 20) {
  if (locationId) {
    return db.prepare(`
      SELECT * FROM alerts
      WHERE location_id = ? OR location_id IS NULL
      ORDER BY created_at DESC LIMIT ?
    `).all(locationId, limit);
  }
  return db.prepare('SELECT * FROM alerts ORDER BY created_at DESC LIMIT ?').all(limit);
}

function getSMSLog(limit = 50) {
  return db.prepare(`
    SELECT s.*, f.name as farmer_name
    FROM sms_log s
    LEFT JOIN farmers f ON f.phone = s.phone
    ORDER BY s.sent_at DESC LIMIT ?
  `).all(limit);
}

module.exports = { createAlert, sendSMS, getAlerts, getSMSLog };
