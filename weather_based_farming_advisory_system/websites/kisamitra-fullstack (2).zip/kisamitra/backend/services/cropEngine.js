// services/cropEngine.js  —  Rule-based crop recommendation logic
// ─────────────────────────────────────────────────────────────
// Each crop entry has:
//   tempRange   [min, max] °C
//   humidRange  [min, max] %
//   rainfall    [min, max] mm/month
//   soils       which soil types support it
//   seasons     kharif | rabi | zaid
//   water       low | medium | high
//   days        growing days

const CROPS = [
  // ──── KHARIF (Jun-Oct) ────
  {
    id: 'soybean', name: 'Soybean', icon: '🫘', season: 'kharif',
    tempRange: [20, 30], humidRange: [60, 85], rainfall: [400, 700],
    soils: ['black', 'alluvial'], water: 'medium', days: '90–110',
    tips: 'Ideal for black cotton soil. Do not over-irrigate — waterlogging causes root rot.',
  },
  {
    id: 'cotton', name: 'Cotton', icon: '🌸', season: 'kharif',
    tempRange: [25, 35], humidRange: [50, 75], rainfall: [500, 900],
    soils: ['black'], water: 'medium', days: '150–180',
    tips: 'Requires deep black soil. Avoid waterlogging. Apply 2 irrigations at boll formation.',
  },
  {
    id: 'paddy', name: 'Paddy / Rice', icon: '🌾', season: 'kharif',
    tempRange: [22, 35], humidRange: [70, 95], rainfall: [900, 2000],
    soils: ['alluvial', 'black'], water: 'high', days: '100–150',
    tips: 'Needs standing water. Best in alluvial soil with canal irrigation.',
  },
  {
    id: 'maize', name: 'Maize', icon: '🌽', season: 'kharif',
    tempRange: [18, 32], humidRange: [50, 80], rainfall: [400, 800],
    soils: ['black', 'red', 'alluvial', 'sandy'], water: 'medium', days: '80–100',
    tips: 'Versatile crop. Ensure good drainage. Apply zinc sulfate if soil is deficient.',
  },
  {
    id: 'groundnut', name: 'Groundnut', icon: '🥜', season: 'kharif',
    tempRange: [22, 32], humidRange: [50, 75], rainfall: [350, 650],
    soils: ['red', 'sandy', 'black'], water: 'low', days: '100–130',
    tips: 'Requires well-drained sandy or red soil. Avoid heavy clay.',
  },
  {
    id: 'pigeonpea', name: 'Pigeon Pea (Tur)', icon: '🌿', season: 'kharif',
    tempRange: [18, 30], humidRange: [40, 70], rainfall: [300, 650],
    soils: ['black', 'red', 'sandy'], water: 'low', days: '120–140',
    tips: 'Drought tolerant. Good for intercropping with soybean or cotton.',
  },
  {
    id: 'sugarcane', name: 'Sugarcane', icon: '🎋', season: 'kharif',
    tempRange: [24, 38], humidRange: [65, 90], rainfall: [1000, 2000],
    soils: ['alluvial', 'black'], water: 'high', days: '300–365',
    tips: 'High water demand. Best with canal or borewell irrigation.',
  },
  // ──── RABI (Nov-Apr) ────
  {
    id: 'wheat', name: 'Wheat', icon: '🌾', season: 'rabi',
    tempRange: [10, 25], humidRange: [40, 65], rainfall: [100, 300],
    soils: ['alluvial', 'black', 'red', 'sandy'], water: 'medium', days: '100–120',
    tips: 'Sow Oct–Nov. Critical irrigations at crown root initiation and grain filling stages.',
  },
  {
    id: 'chickpea', name: 'Chickpea (Gram)', icon: '🫘', season: 'rabi',
    tempRange: [8, 22], humidRange: [30, 60], rainfall: [60, 250],
    soils: ['black', 'sandy', 'red', 'alluvial'], water: 'low', days: '90–100',
    tips: 'Highly drought-tolerant. Grows well on residual soil moisture.',
  },
  {
    id: 'mustard', name: 'Mustard', icon: '🌼', season: 'rabi',
    tempRange: [5, 20], humidRange: [30, 60], rainfall: [50, 200],
    soils: ['sandy', 'alluvial', 'red'], water: 'low', days: '90–110',
    tips: 'Sow Oct–Nov. Best on sandy loam. Very tolerant of cold and dry conditions.',
  },
  {
    id: 'sunflower', name: 'Sunflower', icon: '🌻', season: 'rabi',
    tempRange: [15, 28], humidRange: [40, 70], rainfall: [100, 400],
    soils: ['black', 'red', 'alluvial'], water: 'medium', days: '90–110',
    tips: 'Can be grown in rabi or kharif. Requires well-drained soil. High oil content variety preferred.',
  },
  {
    id: 'barley', name: 'Barley', icon: '🌾', season: 'rabi',
    tempRange: [5, 18], humidRange: [30, 55], rainfall: [50, 180],
    soils: ['sandy', 'alluvial'], water: 'low', days: '80–90',
    tips: 'Hardiest cereal. Can grow in saline/alkaline soils. Needs very little water.',
  },
  // ──── ZAID (Mar-Jun) ────
  {
    id: 'watermelon', name: 'Watermelon', icon: '🍉', season: 'zaid',
    tempRange: [25, 40], humidRange: [40, 70], rainfall: [0, 200],
    soils: ['sandy', 'red', 'black'], water: 'medium', days: '70–90',
    tips: 'Thrives in hot weather. Drip irrigation preferred. Harvest when tendril near fruit dries.',
  },
  {
    id: 'cucumber', name: 'Cucumber', icon: '🥒', season: 'zaid',
    tempRange: [22, 35], humidRange: [50, 80], rainfall: [0, 250],
    soils: ['sandy', 'alluvial', 'red'], water: 'medium', days: '50–60',
    tips: 'Fast-growing. Needs staking or trellis. Irrigate regularly to prevent bitterness.',
  },
  {
    id: 'mungbean', name: 'Mung Bean (Moong)', icon: '🫛', season: 'zaid',
    tempRange: [25, 38], humidRange: [40, 75], rainfall: [0, 300],
    soils: ['sandy', 'red', 'black', 'alluvial'], water: 'low', days: '60–75',
    tips: 'Short duration. Ideal for summer. Fixes atmospheric nitrogen — good for soil health.',
  },
];

// ─────────────────────────────────────────────
//  Score a single crop against current conditions
// ─────────────────────────────────────────────
function scoreCrop(crop, conditions) {
  const { temperature, humidity, rainfall_monthly, soil_type, season, water_availability } = conditions;
  let score = 100;
  const reasons = [];

  // Temperature fit (max deduction: 30 pts)
  const [tMin, tMax] = crop.tempRange;
  if (temperature < tMin) {
    const diff = tMin - temperature;
    score -= Math.min(30, diff * 3);
    reasons.push(`Temp too low (${temperature}°C, ideal: ${tMin}–${tMax}°C)`);
  } else if (temperature > tMax) {
    const diff = temperature - tMax;
    score -= Math.min(30, diff * 3);
    reasons.push(`Temp too high (${temperature}°C, ideal: ${tMin}–${tMax}°C)`);
  } else {
    reasons.push(`Temp ${temperature}°C is ideal ✓`);
  }

  // Humidity fit (max deduction: 20 pts)
  const [hMin, hMax] = crop.humidRange;
  if (humidity < hMin) {
    score -= Math.min(20, (hMin - humidity) * 0.5);
  } else if (humidity > hMax) {
    score -= Math.min(20, (humidity - hMax) * 0.5);
  }

  // Rainfall fit (max deduction: 20 pts)
  const [rMin, rMax] = crop.rainfall;
  if (rainfall_monthly < rMin) {
    const deficit = rMin - rainfall_monthly;
    score -= Math.min(20, deficit * 0.05);
    if (water_availability !== 'none') score += 10; // irrigation compensates
  } else if (rainfall_monthly > rMax) {
    score -= Math.min(20, (rainfall_monthly - rMax) * 0.03);
  }

  // Soil type fit (25 pts)
  if (!crop.soils.includes(soil_type)) {
    score -= 25;
    reasons.push(`Soil not ideal (best: ${crop.soils.join(', ')})`);
  } else {
    reasons.push(`Soil type ${soil_type} matches ✓`);
  }

  // Season fit (only show crops for selected season)
  if (crop.season !== season) score = 0;

  return { ...crop, score: Math.max(0, Math.round(score)), reasons };
}

// ─────────────────────────────────────────────
//  Main recommendation function
// ─────────────────────────────────────────────
function getRecommendations(conditions) {
  const {
    temperature = 28,
    humidity = 65,
    rainfall_monthly = 200,
    soil_type = 'black',
    season = 'kharif',
    water_availability = 'rain',
  } = conditions;

  const scored = CROPS
    .map(c => scoreCrop(c, { temperature, humidity, rainfall_monthly, soil_type, season, water_availability }))
    .filter(c => c.score > 0)
    .sort((a, b) => b.score - a.score);

  const top = scored.slice(0, 6);

  return {
    recommendations: top,
    season,
    conditions: { temperature, humidity, rainfall_monthly, soil_type },
    seasonal_advice: getSeasonalAdvice(season, temperature, humidity),
  };
}

function getSeasonalAdvice(season, temp, humidity) {
  const advice = {
    kharif: {
      label: 'Kharif Season (June – October)',
      emoji: '🌧',
      points: [
        'Prepare fields by deep ploughing in May to break hardpan and improve water absorption.',
        `Current temperature ${temp}°C — ${temp > 28 ? 'ensure adequate irrigation, crops may stress above 32°C' : 'ideal for most kharif sowing'}.`,
        humidity > 75
          ? '⚠️ High humidity detected — monitor for fungal diseases (downy mildew, blight). Apply preventive fungicide.'
          : 'Humidity is within normal range — good conditions for crop growth.',
        'Apply nitrogen fertilizer in two splits — half at sowing, half at 30–35 days after sowing.',
        'Harvest before October end to avoid post-monsoon moisture damage to grain.',
        'Intercrop soybean + pigeonpea (6:2 ratio) to maximize income and reduce pest pressure.',
      ],
    },
    rabi: {
      label: 'Rabi Season (November – April)',
      emoji: '❄️',
      points: [
        'Sow wheat and gram in October–November when soil temperature falls below 25°C.',
        `Current temperature ${temp}°C — ${temp < 15 ? 'frost risk — irrigate lightly on frost-risk nights' : 'suitable for rabi crops'}.`,
        'Maintain 4–5 critical irrigations for wheat: crown root initiation, tillering, jointing, flowering, and grain filling.',
        'Watch for powdery mildew and aphid attack in January–February. Apply appropriate pesticides.',
        'Weed control in first 30–40 days is critical for achieving good yield.',
        'Harvest when grain moisture is below 14% to ensure safe storage.',
      ],
    },
    zaid: {
      label: 'Zaid Season (March – June)',
      emoji: '☀️',
      points: [
        'Choose heat-tolerant varieties — zaid crops must withstand temperatures above 38–40°C.',
        `Current temperature ${temp}°C — ${temp > 36 ? '⚠️ Very high heat — irrigate twice daily, use mulch' : 'manageable for zaid crops with regular irrigation'}.`,
        'Drip or furrow irrigation strongly recommended — evaporation is high in summer.',
        'Short-duration crops preferred: cucumber (50 days), mung bean (60–75 days).',
        'Apply organic mulch (straw, dry leaves) to conserve soil moisture and reduce temperature.',
        'Harvest early morning to preserve freshness and reduce field heat.',
      ],
    },
  };
  return advice[season] || advice.kharif;
}

module.exports = { getRecommendations, CROPS };
