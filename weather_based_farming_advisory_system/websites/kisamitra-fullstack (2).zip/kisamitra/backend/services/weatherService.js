// services/weatherService.js  —  OpenWeatherMap integration
const axios = require('axios');
const db    = require('../db/database');

const API_KEY  = process.env.OPENWEATHER_API_KEY;
const BASE_URL = 'https://api.openweathermap.org/data/2.5';

// ─────────────────────────────────────────────
//  Fetch current weather for a location
// ─────────────────────────────────────────────
async function fetchCurrentWeather(locationId) {
  const loc = db.prepare('SELECT * FROM locations WHERE id = ?').get(locationId);
  if (!loc) throw new Error('Location not found');

  if (!API_KEY || API_KEY === 'your_openweathermap_api_key_here') {
    // Return realistic mock data when no API key is set
    return getMockWeather(loc);
  }

  try {
    const res = await axios.get(`${BASE_URL}/weather`, {
      params: {
        lat:   loc.latitude,
        lon:   loc.longitude,
        appid: API_KEY,
        units: 'metric',
        lang:  'en',
      },
      timeout: 8000,
    });

    const d = res.data;
    const record = {
      location_id:   locationId,
      location_name: loc.name,
      temperature:   d.main.temp,
      feels_like:    d.main.feels_like,
      temp_min:      d.main.temp_min,
      temp_max:      d.main.temp_max,
      humidity:      d.main.humidity,
      pressure:      d.main.pressure,
      wind_speed:    d.wind?.speed ? +(d.wind.speed * 3.6).toFixed(1) : 0, // m/s → km/h
      wind_deg:      d.wind?.deg || 0,
      rainfall_1h:   d.rain?.['1h'] || 0,
      rainfall_24h:  d.rain?.['3h'] || 0,
      cloud_cover:   d.clouds?.all || 0,
      visibility:    d.visibility ? Math.round(d.visibility / 1000) : 10,
      weather_main:  d.weather[0]?.main || '',
      weather_desc:  d.weather[0]?.description || '',
      weather_icon:  d.weather[0]?.icon || '',
      uv_index:      0,
      source:        'openweathermap',
    };

    // Save to DB
    db.prepare(`
      INSERT INTO weather_data
        (location_id, location_name, temperature, feels_like, temp_min, temp_max,
         humidity, pressure, wind_speed, wind_deg, rainfall_1h, rainfall_24h,
         cloud_cover, visibility, weather_main, weather_desc, weather_icon, source)
      VALUES
        (@location_id, @location_name, @temperature, @feels_like, @temp_min, @temp_max,
         @humidity, @pressure, @wind_speed, @wind_deg, @rainfall_1h, @rainfall_24h,
         @cloud_cover, @visibility, @weather_main, @weather_desc, @weather_icon, @source)
    `).run(record);

    return { ...record, location: loc, live: true };
  } catch (err) {
    console.error('OpenWeatherMap error:', err.message);
    // Fallback to last cached reading
    const cached = db.prepare(
      'SELECT * FROM weather_data WHERE location_id = ? ORDER BY recorded_at DESC LIMIT 1'
    ).get(locationId);
    if (cached) return { ...cached, location: loc, live: false, cached: true };
    return getMockWeather(loc);
  }
}

// ─────────────────────────────────────────────
//  Fetch 5-day forecast (3-hour intervals)
// ─────────────────────────────────────────────
async function fetchForecast(locationId) {
  const loc = db.prepare('SELECT * FROM locations WHERE id = ?').get(locationId);
  if (!loc) throw new Error('Location not found');

  if (!API_KEY || API_KEY === 'your_openweathermap_api_key_here') {
    return getMockForecast(loc);
  }

  try {
    const res = await axios.get(`${BASE_URL}/forecast`, {
      params: {
        lat:   loc.latitude,
        lon:   loc.longitude,
        appid: API_KEY,
        units: 'metric',
        cnt:   40, // 5 days × 8 readings/day
      },
      timeout: 8000,
    });

    // Clear old forecasts for this location
    db.prepare('DELETE FROM forecasts WHERE location_id = ?').run(locationId);

    const insert = db.prepare(`
      INSERT INTO forecasts
        (location_id, forecast_time, temperature, temp_min, temp_max, humidity,
         rainfall, wind_speed, weather_main, weather_desc, weather_icon)
      VALUES
        (@location_id, @forecast_time, @temperature, @temp_min, @temp_max, @humidity,
         @rainfall, @wind_speed, @weather_main, @weather_desc, @weather_icon)
    `);

    const items = res.data.list.map(item => ({
      location_id:   locationId,
      forecast_time: item.dt_txt,
      temperature:   item.main.temp,
      temp_min:      item.main.temp_min,
      temp_max:      item.main.temp_max,
      humidity:      item.main.humidity,
      rainfall:      item.rain?.['3h'] || 0,
      wind_speed:    +(item.wind.speed * 3.6).toFixed(1),
      weather_main:  item.weather[0]?.main || '',
      weather_desc:  item.weather[0]?.description || '',
      weather_icon:  item.weather[0]?.icon || '',
    }));

    db.transaction(() => items.forEach(i => insert.run(i)))();
    return { forecast: items, location: loc, live: true };
  } catch (err) {
    console.error('Forecast fetch error:', err.message);
    const cached = db.prepare(
      'SELECT * FROM forecasts WHERE location_id = ? ORDER BY forecast_time LIMIT 40'
    ).all(locationId);
    if (cached.length) return { forecast: cached, location: loc, live: false, cached: true };
    return getMockForecast(loc);
  }
}

// ─────────────────────────────────────────────
//  Get weather history from DB
// ─────────────────────────────────────────────
function getWeatherHistory(locationId, days = 30) {
  return db.prepare(`
    SELECT * FROM weather_data
    WHERE location_id = ?
      AND recorded_at >= datetime('now', ? || ' days')
    ORDER BY recorded_at DESC
  `).all(locationId, `-${days}`);
}

// ─────────────────────────────────────────────
//  Detect extreme weather conditions → generate alerts
// ─────────────────────────────────────────────
function detectExtremeWeather(weatherRecord) {
  const alerts = [];
  const { temperature, humidity, wind_speed, rainfall_1h, weather_main } = weatherRecord;

  if (temperature >= 40) {
    alerts.push({
      type: 'heat', severity: 'danger',
      title: '🌡 Extreme Heat Wave',
      message: `Temperature has reached ${temperature.toFixed(1)}°C. Irrigate crops in early morning or evening only. Provide shade and water for livestock. Avoid field work between 11 AM – 4 PM.`,
    });
  } else if (temperature >= 35) {
    alerts.push({
      type: 'heat', severity: 'warning',
      title: '⚠️ High Temperature Alert',
      message: `Temperature at ${temperature.toFixed(1)}°C. Increase irrigation frequency. Monitor crops for heat stress.`,
    });
  }

  if (rainfall_1h >= 50) {
    alerts.push({
      type: 'storm', severity: 'danger',
      title: '🌊 Flash Flood Risk',
      message: `Heavy rainfall: ${rainfall_1h} mm in last hour. Evacuate low-lying fields. Secure livestock. Do not venture into flooded areas.`,
    });
  } else if (rainfall_1h >= 20) {
    alerts.push({
      type: 'rain', severity: 'warning',
      title: '🌧 Heavy Rainfall Alert',
      message: `${rainfall_1h} mm rainfall recorded. Check drainage channels. Delay pesticide application by at least 24 hours.`,
    });
  }

  if (wind_speed >= 60) {
    alerts.push({
      type: 'storm', severity: 'danger',
      title: '🌪 High Wind Warning',
      message: `Wind speed at ${wind_speed} km/h. Secure polytunnels and shade nets. Avoid spraying operations.`,
    });
  }

  if (weather_main === 'Thunderstorm') {
    alerts.push({
      type: 'storm', severity: 'warning',
      title: '⛈ Thunderstorm Alert',
      message: 'Active thunderstorm detected. Seek shelter immediately. Unplug electrical equipment. Secure loose farm materials.',
    });
  }

  if (humidity <= 20 && temperature >= 30) {
    alerts.push({
      type: 'drought', severity: 'warning',
      title: '🏜 Drought Stress Conditions',
      message: `Very low humidity (${humidity}%) with high temperature. Increase irrigation immediately. Mulch soil to retain moisture.`,
    });
  }

  return alerts;
}

// ─────────────────────────────────────────────
//  Mock data for demo / no-API-key mode
// ─────────────────────────────────────────────
function getMockWeather(loc) {
  const now = new Date();
  const hour = now.getHours();
  // Simulate realistic diurnal temperature cycle
  const baseTemp = { Nashik: 28, Pune: 27, Nagpur: 32, Aurangabad: 30, Kolhapur: 25 };
  const base = baseTemp[loc.name] || 28;
  const diurnal = Math.sin((hour - 6) * Math.PI / 12) * 5;
  const temp = +(base + diurnal + (Math.random() * 2 - 1)).toFixed(1);

  const conditions = [
    { main: 'Clouds', desc: 'partly cloudy', icon: '02d' },
    { main: 'Rain',   desc: 'light rain',    icon: '10d' },
    { main: 'Clear',  desc: 'clear sky',     icon: '01d' },
  ];
  const cond = conditions[Math.floor(Math.random() * conditions.length)];

  return {
    location_id:   loc.id,
    location_name: loc.name,
    temperature:   temp,
    feels_like:    +(temp + 2.5).toFixed(1),
    temp_min:      +(temp - 4).toFixed(1),
    temp_max:      +(temp + 5).toFixed(1),
    humidity:      Math.floor(60 + Math.random() * 25),
    pressure:      Math.floor(1008 + Math.random() * 10),
    wind_speed:    +(10 + Math.random() * 15).toFixed(1),
    wind_deg:      Math.floor(Math.random() * 360),
    rainfall_1h:   cond.main === 'Rain' ? +(Math.random() * 8).toFixed(1) : 0,
    rainfall_24h:  cond.main === 'Rain' ? +(Math.random() * 25).toFixed(1) : 0,
    cloud_cover:   Math.floor(Math.random() * 80),
    visibility:    Math.floor(8 + Math.random() * 6),
    weather_main:  cond.main,
    weather_desc:  cond.desc,
    weather_icon:  cond.icon,
    uv_index:      +(3 + Math.random() * 5).toFixed(1),
    location:      loc,
    live:          false,
    mock:          true,
  };
}

function getMockForecast(loc) {
  const days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const forecast = Array.from({ length: 40 }, (_, i) => {
    const dt = new Date(Date.now() + i * 3 * 3600 * 1000);
    const h  = dt.getHours();
    const t  = 26 + Math.sin((h - 6) * Math.PI / 12) * 6 + (Math.random() * 4 - 2);
    const rainy = Math.random() > 0.65;
    return {
      forecast_time: dt.toISOString().slice(0, 19).replace('T', ' '),
      temperature:   +t.toFixed(1),
      temp_min:      +(t - 4).toFixed(1),
      temp_max:      +(t + 5).toFixed(1),
      humidity:      Math.floor(55 + Math.random() * 35),
      rainfall:      rainy ? +(Math.random() * 12).toFixed(1) : 0,
      wind_speed:    +(8 + Math.random() * 18).toFixed(1),
      weather_main:  rainy ? 'Rain' : 'Clouds',
      weather_desc:  rainy ? 'moderate rain' : 'few clouds',
      weather_icon:  rainy ? '10d' : '03d',
    };
  });
  return { forecast, location: loc, live: false, mock: true };
}

module.exports = { fetchCurrentWeather, fetchForecast, getWeatherHistory, detectExtremeWeather };
